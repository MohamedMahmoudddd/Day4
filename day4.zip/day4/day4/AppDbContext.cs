﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using Day4.Ecommerce;
using Day4.Health_Care;
using Day4.Library;
using Microsoft.EntityFrameworkCore;

namespace Day4.Ecommerce
{
    internal class AppDbContext:DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=.;DataBase=Ecommerce;Trusted_Connection=True;TrustServerCertificate=True");

        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<OrderDetail>()
                .HasKey(od => new { od.OrderId, od.ProductId });
            modelBuilder.Entity<Category>()
                .HasMany(c => c.Products)
                .WithOne(p => p.Category)
                .HasForeignKey(p => p.CategoryId);


            modelBuilder.Entity<Customer>()
                .HasMany(C=>C.orders)
                .WithOne(O=>O.Customer)
                .HasForeignKey(O=>O.CustomerId);
//Proj 2
            modelBuilder.Entity<Loan>()
                .HasKey(L => new { L.BorrowerId, L.BookId });

            modelBuilder.Entity<Book>()
                .HasMany(B=>B.Loans)
                .WithOne(L=>L.Book)
                .HasForeignKey(L=>L.BookId);

            modelBuilder.Entity<Borrower>()
                .HasMany(B => B.Loans)
                .WithOne(L => L.Borrower)
                .HasForeignKey(L => L.BorrowerId);
            modelBuilder.Entity<Author>()
                .HasMany(A => A.Books)
                .WithOne(B => B.Author)
                .HasForeignKey(B => B.AuthorId);
            //Proj3
            modelBuilder.Entity<Appointment>()
                .HasKey(A => new {A.DoctorId,A.PatientId});
            modelBuilder.Entity<patient>()
                .HasMany(p => p.Appointments)
                .WithOne(A => A.patient)
                .HasForeignKey(A => A.PatientId);

            modelBuilder.Entity<Doctor>()
               .HasMany(D => D.Appointments)
               .WithOne(A => A.Doctor)
               .HasForeignKey(A => A.DoctorId);

        }

        public DbSet<Category> Categories { get; set; }

        public DbSet<Product> Products { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<Order>Orders { get; set; }
        public DbSet<OrderDetail> OrderDetails { get; set; }

        public DbSet<Book> Books { get; set; }
        public DbSet<Author > Authors { get; set; }
        public DbSet<Borrower> Borrowers { get; set; }
        public DbSet<Loan> Loans { get; set; }

        public DbSet<Doctor> Doctors { get; set; }
        public DbSet<patient> patients { get; set; }
        public DbSet<Appointment> Appointments { get; set; }

    }
}
